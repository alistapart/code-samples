<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
	<title></title>
	<style type="text/css">
		@import "finder.css";
	</style>
	<script type="text/javascript" src="orderfinder.js"></script>
</head>
<body>
<?PHP
	$menuitems=array(null,'Quarter Pounder','Half Pounder','Cheese Burger','Double Burger','Ranch Burger','Chargrilled Chicken','Chicken Burger','Fish Burger',"Fisherman's Delight",'Brownies','Cookies','Normal Fries','Cheesy Fries','Curry Fries' ,'Curly Fries','Chocolate Shake','Vanilla Shake','Strawberry Shake','Banana Shake','Coke','Lemonade','Sprite','Mountain Dew','Dr.Pepper','Tom Collins','Tequila Sunrise','Sea Breeze','Virgin Mary','Bloody Mary','Natural Apple Juice','Clear Apple Juice','Orange','Cranberry','Kiwi','Pineapple','Tuna Salad','Cesar Salad','Green Salad','Prawn Salad','Short Pancake Stack','Long Pancake Stack','Waffles with ice cream','Waffles with syrup','Mixed Cup','Banana Split','Melon Medley','Seasonal Fruit');
	$a=strip_tags($_GET['a']);
	$item=strip_tags($_GET['item']);
	$items=$item==''?$a:$item.'|'.$a;
?>
<div id="finderparent">
	<ul id="finder">
		<li>Main Courses
			<ul>
				<li>Burger Meals
					<ul>
						<li>Beef
							<ul>
								<li><a href="order.php?a=1&#38;item=<?=$items?>">Quarter Pounder</a></li>
								<li><a href="order.php?a=2&#38;item=<?=$items?>">Half Pounder</a></li>
								<li><a href="order.php?a=3&#38;item=<?=$items?>">Cheese Burger</a></li>
								<li><a href="order.php?a=4&#38;item=<?=$items?>">Double Burger</a></li>
								<li><a href="order.php?a=5&#38;item=<?=$items?>">Ranch Burger</a></li>
							</ul>
						</li>
						<li>Chicken
							<ul>
								<li><a href="order.php?a=6&#38;item=<?=$items?>">Chargrilled Chicken</a></li>
								<li><a href="order.php?a=7&#38;item=<?=$items?>">Chicken Burger</a></li>
							</ul>
						</li>
						<li>Fish
							<ul>
								<li><a href="order.php?a=8&#38;item=<?=$items?>">Fish Burger</a></li>
								<li><a href="order.php?a=9&#38;item=<?=$items?>">Fisherman's Delight</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li>Snacks
					<ul>
						<li><a href="order.php?a=10&#38;item=<?=$items?>">Brownies</a></li>
						<li><a href="order.php?a=11&#38;item=<?=$items?>">Cookies</a></li>
						<li>Fries
							<ul>
								<li><a href="order.php?a=12&#38;item=<?=$items?>">Normal Fries</a></li>
								<li><a href="order.php?a=13&#38;item=<?=$items?>">Cheesy Fries</a></li>
								<li><a href="order.php?a=14&#38;item=<?=$items?>">Curry Fries</a></li>
								<li><a href="order.php?a=15&#38;item=<?=$items?>">Curly Fries</a></li>
							</ul>
						</li>
					</ul>
				</li>
			</ul>
		</li>
		<li>Drinks
			<ul>
				<li>Shakes
					<ul>
						<li><a href="order.php?a=16&#38;item=<?=$items?>">Chocolate</a></li>
						<li><a href="order.php?a=17&#38;item=<?=$items?>">Vanilla</a></li>
						<li><a href="order.php?a=18&#38;item=<?=$items?>">Strawberry</a></li>
						<li><a href="order.php?a=19&#38;item=<?=$items?>">Banana</a></li>
					</ul>
				</li>
				<li>Sodas
					<ul>
						<li><a href="order.php?a=20&#38;item=<?=$items?>">Coke</a></li>
						<li><a href="order.php?a=21&#38;item=<?=$items?>">Lemonade</a></li>
						<li><a href="order.php?a=22&#38;item=<?=$items?>">Sprite</a></li>
						<li><a href="order.php?a=23&#38;item=<?=$items?>">Mountain Dew</a></li>
						<li><a href="order.php?a=24&#38;item=<?=$items?>">Dr.Pepper</a></li>
					</ul>
				</li>
				<li>Cocktails
					<ul>
						<li><a href="order.php?a=25&#38;item=<?=$items?>">Tom Collins</a></li>
						<li><a href="order.php?a=26&#38;item=<?=$items?>">Tequila Sunrise</a></li>
						<li><a href="order.php?a=27&#38;item=<?=$items?>">Sea Breeze</a></li>
						<li><a href="order.php?a=28&#38;item=<?=$items?>">Virgin Mary</a></li>
						<li><a href="order.php?a=29&#38;item=<?=$items?>">Bloody Mary</a></li>
					</ul>
				</li>
				<li>Juices
					<ul>
						<li>Apple
							<ul>
								<li><a href="order.php?a=30&#38;item=<?=$items?>">Natural</a></li>
								<li><a href="order.php?a=31&#38;item=<?=$items?>">Clear</a></li>
							</ul>
						</li>
						<li><a href="order.php?a=32&#38;item=<?=$items;?>">Orange</a></li>
						<li><a href="order.php?a=33&#38;item=<?=$items;?>">Cranberry</a></li>
						<li><a href="order.php?a=34&#38;item=<?=$items;?>">Kiwi</a></li>
						<li><a href="order.php?a=35&#38;item=<?=$items;?>">Pineapple</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li>Salads
			<ul>
				<li><a href="order.php?a=36&#38;item=<?=$items;?>">Tuna Salad</a></li>
				<li><a href="order.php?a=37&#38;item=<?=$items;?>">Cesar Salad</a></li>
				<li><a href="order.php?a=38&#38;item=<?=$items;?>">Green Salad</a></li>
				<li><a href="order.php?a=39&#38;item=<?=$items;?>">Prawn Salad</a></li>
			</ul>
		</li>
		<li>Deserts
			<ul>
				<li>Pancakes
					<ul>
						<li><a href="order.php?a=40&#38;item=<?=$items;?>">Short Stack</a></li>
						<li><a href="order.php?a=41&#38;item=<?=$items;?>">Long Stack</a></li>
					</ul>
				</li>
				<li>Waffles
					<ul>
						<li><a href="order.php?a=42&#38;item=<?=$items;?>">Waffles with ice cream</a></li>
						<li><a href="order.php?a=43&#38;item=<?=$items;?>">Waffles with syrup</a></li>
					</ul>
				</li>
				<li>Ice Cream
					<ul>
						<li><a href="order.php?a=44&#38;item=<?=$items;?>">Mixed Cup</a></li>
						<li><a href="order.php?a=45&#38;item=<?=$items;?>">Banana Split</a></li>
					</ul>
				</li>
				<li>Fresh Fruit
					<ul>
						<li><a href="order.php?a=46&#38;item=<?=$items;?>">Melon Medley</a></li>
						<li><a href="order.php?a=47&#38;item=<?=$items;?>">Seasonal Fruit</a></li>
					</ul>
				</li>
			</ul>
		</li>
	</ul>
</div>
<div id="orders">
<?PHP
if($item!='')
{
	$ordered=split('\|',$item);
	for($i=0;$i<sizeof($ordered);$i++)
	{
		echo '<p>'.$menuitems[$ordered[$i]].'</p>';
	}
}
	echo '<p>'.$menuitems[$a].'</p>';
?>
</div>

<form action="orders.php" method="get">
	<input type="hidden" id="items" name="items" value="<?=$items?>" />
	<input type="submit" value="Order" />
</form>

</body>
</html>
