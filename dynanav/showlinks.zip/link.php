 <?PHP
	/* 
	 *  link.php
	 *	Adds a navigation dropdown to the document, which gets
	 *  populated by the data in the LINK tags of the document
	 *  written by Christian Heilmann (http://icant.co.uk/)
	 *
	 * Usage:
	 * loop the page you want to scan and add the dropdown to 
	 * link.php?p=foo.html
	*/
	$elementid='linksnavigation'; 
	$elementtype='div';
	$dropdownlabel='Quick Jump to:';
	$dropdownbutton='jump';
	$dropdownid='linksnavigationdropdown';
	if(isset($_POST[$dropdownid]))
	{
		header('Location:'.$_POST[$dropdownid]);
	}else if(isset($_GET['p'])){
		$doc=$_GET['p'];
		if(file_exists($doc))
		{
			$fd = fopen($doc,"r"); 
			while(!feof($fd))
			{ 
			   $content .= fgets($fd, 4096); 
			} 
			fclose ($fd);	
		}
		preg_match_all('/<link(.*?)>/',$content,$links);
		foreach($links[1] as $l)
		{
			if(!preg_match('/style/i',$l))
			{
				preg_match('/title="(.*?)"/',$l,$title);
				$titles[]=$title[1];
				preg_match('/href="(.*?)"/',$l,$href);
				$hrefs[]=$href[1];
			}
		}
		$form.='<form action="link.php" method="post">';
		$form.='<label for="'.$dropdownid.'">'.$dropdownlabel.'</label>';
		$form.='<select id="'.$dropdownid.'" name="'.$dropdownid.'">';
		foreach($titles as $k=>$t)
		{
			$form.='<option value="'.$hrefs[$k].'">'.$t.'</option>';
		}
		$form.='</select>';
		$form.='<input type="submit" value="'.$dropdownbutton.'" />';
		$form.='</form>';
		$content=preg_replace('/showlinks.js/','',$content);
		if (preg_match('/id="'.$elementid.'"/',$content)){
			$content=preg_replace('/id="'.$elementid.'"(.*?)></','id="'.$elementid.'"\\1>'.$form.'<',$content);
		} else {
			$content=preg_replace('/<body(.*?)>/','<body\\1><'.$elementtype.' id="'.$elementid.'">'.$form.'</'.$elementtype.'>',$content);
		}
		echo $content;
	}
?>